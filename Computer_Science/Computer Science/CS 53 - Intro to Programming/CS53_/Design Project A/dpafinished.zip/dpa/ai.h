/*
 * Author: Ryan Alyea
 * Date: 3/1/06
 * Filename: ai.h
 * Instructor: Brian Sea
 * Description: Main function for DPA
 */

#ifndef ai_h
#define ai_h

#include <ctime>
#include <string>
#include "card.h"

const unsigned int NUM_AI_PLAYERS = 5;
const unsigned int STARTING_MONEY = 500;

struct Player {
  unsigned int money;
  Card card1;
  Card card2;
  bool isHuman;
  bool isDead;
  bool isFolded;
  unsigned int bet;
};

// function: createAI
// Purpse:
//   This function creates and initalizes an AI player
// Arguments:
//   ai  -  The AI to be initalized
// Returns: Nothing
// Precondition: ai is an AI type that's supposted to be empty
// Postcondition: gives ai money and other stuff to start wtih
void createAI (Player &ai);

// function: sleep
// Purpose:
//   This function causes the CPU to wait for seconds for dramatic effect
// Arguments
//   mseconds - time to wait in seconds
// precondition: none
// postcondition: system hangs for set amount of time
// returns: nata

void sleep2(unsigned int seconds);

#endif
