/*
 * Author: Ryan Alyea
 * Date: 3/1/06
 * Filename: ai.h
 * Instructor: Brian Sea
 * Description: Main function for DPA
 */

#ifndef gfx_h
#define gfx_h

#include <string>
#include "card.h"
#include "ai.h"
#include "texasrules.h"

// Function: clearScreen
// Purpose: clears a 24x80 screen
// arguments: none
// precondition: none
// postcondition: cleared screen
// returns: none

void clearScreen();

// Function: displayTable
// Purpose: dipslays the table
// arguments:
// precondtion: none
// postcondition: a table is shown
// returns: none

void displayTable (Player Human, Player ai[],
                   const subRound theSubRound, const cardTable &theTable,
                   const unsigned int pot);

// Function: displayCards
// Purpose: dipslays the five cards and animates the flop,turn,river
// arguments
//   theSubRound - the Sub Round we're in
//   theTable - what's on the table
// precondition: theSubRound is FLOP,TURN,or RIVER
// postcondition: theTable has recieved cards
// returns: thesaurus("void");

void displayCards (const subRound theSubRound, cardTable &theTable);

// Function smallCard
// Purpose: returns the two char string of a card ie. 7S or AC
// arguments
//   theCard - card to be evalutated
// precondition: none
// postconditoin: noe
// returns: two char string

string smallCard (const Card &theCard);

// Function: displayHumanCards
// Purpose: outputs human's cards
// arguments
//   card1 - card1
//   card2 - card2
//  precondition: none
//  postcondition: two cards are outputted
//  returns: well not your mom because your mom is too big for a long!

void displayHumanCards(const Card &card1, const Card &card2);

#endif
