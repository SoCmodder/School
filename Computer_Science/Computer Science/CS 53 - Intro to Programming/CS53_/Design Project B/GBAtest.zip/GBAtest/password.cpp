/*
 * Author: Ryan Alyea
 * Date: 4/18/06
 * Filename: password.cpp
 * Instructor: Brian Sea
 * Description: Password class for GBA Texas Hold'em
 */

#include "/opt/local/devkitpro/libgba/include/gba_input.h"
#include "/opt/local/devkitpro/libgba/include/gba_systemcalls.h"

#include "password.h"
#include "GFX.h"
#include <string>
using namespace std;

void Password::setPassword(const string &name, GFX &screen) {
  PasswordTemp temp;
  temp = screen.password(name);
  this->pass1 = temp.pass[0];
  this->pass2 = temp.pass[1];
  this->pass3 = temp.pass[2];
  this->pass4 = temp.pass[3];
  this->pass5 = temp.pass[4];
}

void Password::askPassword(const string &name, GFX &screen) {
  PasswordTemp temp;
  while (true) {
    temp = screen.password(name);
	// why the weird tree? because it's the only way i could get it to work
	if (temp.pass[0] == this->pass1){
	  if (temp.pass[1] == this->pass2) {
	    if (temp.pass[2] == this->pass3) {
		  if (temp.pass[3] == this->pass4) {
		    if (temp.pass[4] == this->pass5) {
			  break;
			}
		  }
		}
	  }
	}
  }
}
