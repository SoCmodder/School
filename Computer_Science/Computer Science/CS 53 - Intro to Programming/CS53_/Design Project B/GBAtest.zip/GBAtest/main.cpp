/*
 * Author: Ryan Alyea
 * Date: 4/11/06
 * Filename: main.cpp
 * Instructor: Brian Sea
 * Description: Main for the GBA Texas Hold'em
 */

// GBA based include files
#include "/opt/local/devkitpro/libgba/include/gba_systemcalls.h"

// real includes
#include <string>
using namespace std;

// Class includes
#include "GFX.h"
#include "password.h"
#include "global.h"

// Program entry point
int main(void) {

  string name;
  Password temp;

  GFX screen;
  screen.titleScreen();
  //name = screen.inputText("What is your name?");
  temp.setPassword("ryan",screen);
  temp.askPassword("ryan",screen);
  

  while (1) {
    VBlankIntrWait();
  }
}
