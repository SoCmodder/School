/*
 * Author: Ryan Alyea
 * Date: 4/11/06
 * Filename: GFX.h
 * Instructor: Brian Sea
 * Description: GFX class for GBA Texas Hold'em
 */
 
 #ifndef GFX_h
 #define GFX_h
 
 #include "/opt/local/devkitpro/libgba/include/gba_types.h"
 #include <string>
 using namespace std;
 
struct PasswordTemp {
  int pass[5];
};
 
class GFX {
//34567890123456789012345678901234567890123456789012345678901234567890123456

 private:
  class SpriteClass {
   public:
    u16 *attr1;
	u16 *attr2;
	u16 *attr3;
	
	//function: setID
	//description: constructor for a sprite (not to be confused with the soda)
	//argument:
	//  - spriteID = the ID to set it up for
	//precondition: spriteID <= 128
	//postcondition: none
	//returns: the value of Enron stock
	void setID(u8 spriteID);
	
	void setattr1(u16 attr);
	void setattr2(u16 attr);
	void setattr3(u16 attr);
  };

  // video explaination: these are the addresses for the video memory. this
  // program works in Mode 4. That means that the video is a 0-255 value
  // pointing to a palette containing a color. video is screen 1,
  // video2 is screen 2. (only one can be shown at a time), and palette
  // leads to the palette data. u8 just means unsigned char and u16 means
  // unsigned short. It just helps me know how many bits are defined.
  u8 *video;
  u8 *video2;
  u16 *palette;
  // sprite is like 7-up
  SpriteClass sprite[128];
  // how many sprites are dedicated to letters
  u8 lettersprites;
 
 public:
  //Function: GFX
  //Description: constructor, initalizes the screen
  //Arguments: none
  //precondition: none
  //postcondition: initalized screen ready for pixels
  //returns: not even a return type ;)
  GFX();
  
  //Function: setPalette
  //Description: sets a specific to the palette
  //Arguments:
  //  - paletteNum = the paletteNumber
  //  =====
  //  - red = red intensity
  //  - green = green intensity
  //  - blue = blue intensity
  //  == OR ==
  //  - color = all the colors in one
  //precondition:
  //  - paletteNum is between 0 - 255
  //  - red/blue/green is between 0-31
  //postcondition: a set color
  //returns: teh void
  void setPalette(u8 paletteNum, unsigned char red,
                  unsigned char green, unsigned char blue);
  void setPalette(u8 paletteNum, u16 color);
  
  //Function: setPixel
  //Description: sets a specific pixel a palleteNum
  //Arguments:
  //  - X = X location of pixel
  //  - Y = Y location of pixel
  //  - color = color in RGB8 format
  //precondition: X <= 240, Y <= 160, (0,0) is upper left, (240,160) is lower right
  //postcondition: a pixel appears! 32 HP, Will you: Attack Guard Item Pray or Steal?
  //returns: noid the void
  void setPixel(unsigned char X, unsigned char Y, u8 paletteNum);
  
  //Function: titleScreen
  //Description: a titlescreen with "press A to continue" and asks how many human players
  //Arguments: none
  //precondition: none
  //postcondition: after the function's finished, there might be some memory leftovers
  //returns: a number from 1-5 stating the number of human players
  int titleScreen();
  
  //Function: setSTDPalette
  //Description: Sets the standard palette used for everything.
  //  note: this is the 'Windows' palette as defined in Photoshop CS1
  //Arguments: none
  //precondition: none
  //postcondition: standard palette is set.
  //returns: your mom
  void setSTDPalette();
  
  //Function: setSTDText
  //Description: Sets the standard Text rows in the sprite memory.
  //Arguments: none
  //precondition: none
  //postcondition: standard text tiles set in OAM memory
  //returns: lol, void
  void setSTDText();
  
  //Function: inputText
  //Description: Input text screen
  //Arguments: Question = what question to ask
  //precondition: none:
  //postcondition: memory leftovers
  //returns: string from input.
  string inputText(string question);
  
  //Function: drawChar
  //Description: draws a character
  //Arguments:
  //  - letter = letter to be drawn
  //  - X = X coordinate
  //  - Y = Y coordinate
  //  - spriteID = spriteID to use
  //precondition: none
  //postcondition: drawn character using a sprite, lettersprite++
  //returns: u tell me
  void drawChar(char letter, u8 X, u8 Y, u8 spriteID);
  
  //Function: drawString
  //Description: draws a semi-variable length string
  //Arguments:
  //  - word = string to be drawn
  //  - X
  //  - Y = X/Y coordinates
  //precondition: none
  //postcondition: chars are drawn
  //returns: void
  void drawString(const string &word, u8 X, u8 Y);
  
  //Function: wipeChars
  //Description: clears all the chars from the screen
  //arguments: none
  //precondition: none
  //postcondition: all the Chars are wiped
  //returns: too tired to be witty
  void wipeChars();
  
  //function: ZOMFGPANIC
  //description: PANIC!!!!11!!!1 and red screen
  //  in reality: it checks for a panic condition,
  //  such as out of memory and if it does, then panic
  //arguments: none
  //precondition: none
  //postcondition: a red screen
  //returns: PANIC!!!!!!!!!
  void ZOMFGPANIC();
  
  //function: password
  //description: do the password sequence
  //arguments: name = the name of the user
  //precondition: none
  //postcondition: none (some VRAM memory residue)
  //returns: a password based on DPAD
  PasswordTemp password(const string &name);

};

#endif
