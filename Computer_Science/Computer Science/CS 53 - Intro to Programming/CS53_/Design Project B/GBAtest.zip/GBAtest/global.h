/*
 * Author: Ryan Alyea
 * Date: 4/17/06
 * Filename: global.h
 * Instructor: Brian Sea
 * Description: global functions for GBA Texas Hold'em
 */
 
