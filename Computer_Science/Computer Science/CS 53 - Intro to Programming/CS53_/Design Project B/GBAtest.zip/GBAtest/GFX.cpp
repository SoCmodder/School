/*
 * Author: Ryan Alyea
 * Date: 4/11/06
 * Filename: GFX.cpp
 * Instructor: Brian Sea
 * Description: Graphics for GBA
 */

#include "/opt/local/devkitpro/libgba/include/gba_video.h"
#include "/opt/local/devkitpro/libgba/include/gba_interrupt.h"
#include "/opt/local/devkitpro/libgba/include/gba_systemcalls.h"
#include "/opt/local/devkitpro/libgba/include/gba_dma.h"
#include "/opt/local/devkitpro/libgba/include/gba_console.h"
#include "/opt/local/devkitpro/libgba/include/gba_input.h"
#include "/opt/local/devkitpro/libgba/include/gba_sprites.h"

#include <stdio.h>
#include <cstdlib>
#include <string>
using namespace std;
 
#include "GFX.h"
#include "password.h"

// include graphics files
#include "TitleScreen.h"
#include "TitleScreen2.h"
#include "stdPalette.h"
#include "HowManyPlayers.h"
#include "triangle.h"
#include "font.h"
#include "inputscreen.h"
#include "arrows.h"

const u8 allwhite [] = {0x00,0x00};
 
GFX::GFX() {
	// the vblank interrupt must be enabled for VBlankIntrWait() to work
	// since the default dispatcher handles the bios flags no vblank handler
	// is required
  InitInterrupt();
  EnableInterrupt(IE_VBL);
  // this sets the GBA so that it's in Mode 4 mode, and turns BG 2 on
  *(u16*)0x04000000 = MODE_4 | BG2_ON; //3 | (1<<10);
  video = (u8*)0x06000000;
  video2 = (u8*)0x0600A000;
  palette = (u16*)0x05000000;
  for (u8 i = 0; i < 128; i++) {
    sprite[i].setID(i);
  }
  lettersprites = 0;
}

void GFX::SpriteClass::setID(u8 spriteID) {
  attr1 = ((u16*)0x07000000) + (spriteID * 8);
  attr2 = ((u16*)0x07000002) + (spriteID * 8);
  attr3 = ((u16*)0x07000004) + (spriteID * 8);
}

void GFX::SpriteClass::setattr1(u16 attr) {
  attr1[0] = attr;
}

void GFX::SpriteClass::setattr2(u16 attr) {
  attr2[0] = attr;
}

void GFX::SpriteClass::setattr3(u16 attr) {
  attr3[0] = attr;
}

void GFX::setPalette(u8 paletteNum, unsigned char red,
                unsigned char green, unsigned char blue) {
  u16 temp;
  temp = RGB5(red,green,blue);
  this->setPalette(paletteNum,temp);
}

void GFX::setPalette(u8 paletteNum, u16 color) {
  this->palette[paletteNum] = color;
}

void GFX::setPixel(unsigned char X, unsigned char Y, u8 paletteNum) {
  this->video[(X*240) + Y] = paletteNum;
}

int GFX::titleScreen() {
  // this takes some explaining: this DMA means to copy memory from a
  // destination address, in this case, a table containing the palette data,
  // a location address, in this case, the real palette table on the
  // on the hardware. The next are a bunch of qualifiers. 256 means move
  // 256 parts of data, DMA16 means each part is 16 bits big.
  // DMA_DST_INC and DMA_SRC_INC means increase the destination and source
  // addresses by one for each part, and DMA_IMMEDIATE means run right now.
  DMA3COPY((u32)titlePal,(u32)palette,256|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
  // moves the pixel data from the block table to the video.
  DMA3COPY((u32)titleBlk,(u32)video,19200|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
  // moves the pixel data from the 2nd block table into the backbuffer
  DMA3COPY((u32)title2Blk,(u32)video2,19200|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);

  // copy current graphic mode data into temp
  u16 temp = *(u16*)0x04000000;
  // initalize keys variable
  int keys;
  // while something
  while (1) {

    // wait for VBlank 20 times. VBlank occurs every 1/60 of a second and
    // updates the physical LCD. During this time, store all key presses
	// into "keys"
    for (int i = 0; i < 20; i++) {
	  ScanKeys();
	  keys = keys | KeysDown();
      VBlankIntrWait();
    }
	
	// if the start key was pressed during the above time, break
	if (keys & KEY_START)
	  break;

	// if the backbuffer is set
	if (*(u16*)0x04000000 & BACKBUFFER)
	  // set the graphics mode to it's original format
	  *(u16*)0x04000000 = temp;
	else
	  // otherwise set it to original and use backbuffer
	  *(u16*)0x04000000 = temp | BACKBUFFER;
//34567890123456789012345678901234567890123456789012345678901234567890123456	
	// short version: the above switches the screen from the main buffer
	// to the backbuffer or vice versa every 1/3 second. The physical effect
	// is that the "Press Start to Continue" is flashed. When "start" is
	// actually pressed, continue on...
  }
  // set the graphics mode to it's original format and turn on objects/sprites
  *(u16*)0x04000000 = temp | OBJ_ON;  
  // set the standard pallete, used for everything else from now on.
  this->setSTDPalette();
  // send the HowManyPlayers screen to video
  DMA3COPY((u32)HowManyPlayers,(u32)video,19200|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
  // send the blinking triangle graphic to sprite memory
  DMA3COPY((u32)triangle,(u32)0x06014000,64|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
  DMA3COPY((u32)triangle+128,(u32)0x06014400,64|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
  
  // set the triangle's defaults values. In this case, 120 pixels from the top, 8 pixels
  // from the right, use 256 color, size(1) = 16x16 size, and it starts at point 512.
  //*(u16*)0x07000000 = OBJ_Y(120)|OBJ_256_COLOR;
  //*(u16*)0x07000002 = OBJ_X(8)|OBJ_SIZE(1);
  //*(u16*)0x07000004 = OBJ_CHAR(512);

  sprite[0].setattr1(OBJ_Y(120)|OBJ_256_COLOR);
  sprite[0].setattr2(OBJ_X(8)|OBJ_SIZE(1));
  sprite[0].setattr3(OBJ_CHAR(512));
  
  // set the actual return data and a blink data
  int ret = 1;
  int blink = 0;
  // while true (until break)
  while (1) {
    // increase the blink
    blink++;
	// if blink is 60 or more, set it to normal
	if (blink >= 60) {
	  blink = 0;
	  sprite[0].setattr1(OBJ_Y(120)|OBJ_256_COLOR);
	}
	// else if the blink is 45, turn it off
	else if (blink == 45) {
      sprite[0].setattr1(OBJ_Y(120)|OBJ_256_COLOR|OBJ_DISABLE);
	}
	// this above causes the triangle to blink
	// QuickQuestion: Why don't you use '%'? The GBA does not have a hardware divisor unit
	//   that means that anything involving dividing, including '/' or '%' is VERY slow.
	//   It is up to the programmer to find alternate ways to do the same things, but faster
	//   for a specific piece of hardware.
	
	// scan for the keys
	ScanKeys();
	// set what's down to a variable
	keys = KeysDown();
	// if left is pushed, and it isn't already the min value 1, lower it, and update the
	// triangle's position, and blink = 0 so the blinking doesn't occur when moving
	if (keys & KEY_LEFT && ret > 1) {
	  ret--;
	  sprite[0].setattr2(OBJ_X(8+((ret-1)*51))|OBJ_SIZE(1));
	  blink = 0;
	}
	// same thing, except with right and increasing
	else if (keys & KEY_RIGHT && ret < 5) {
	  ret++;
	  sprite[0].setattr2(OBJ_X(8+((ret-1)*51))|OBJ_SIZE(1));
	  blink = 0;
	}
	// if somebody has pushed A or START, than continue
	else if (keys & (KEY_A | KEY_START))
	  break;
	// otherwise if none of the applicable keys were pressed, than
	// wait for VBlank (1/60th of a second) then try again.
	VBlankIntrWait();
  }
  // return the number of Human Players.
  sprite[0].setattr1(0);
  sprite[0].setattr2(0);
  sprite[0].setattr3(0);
  return ret;
}

void GFX::setSTDPalette() {
  DMA3COPY((u32)stdPalette,(u32)palette,256|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
  DMA3COPY((u32)stdPalette,(u32)0x05000200,256|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
}

void GFX::setSTDText() {
  DMA3COPY((u32)font,(u32)0x06014000,3008|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
}

string GFX::inputText(string question) {
  // move inputscreen background into video
  DMA3COPY((u32)inputscreen,(u32)video,19200|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
  // setup the sprite text data
  this->setSTDText();
  // move the 'select' triangle into memory
  DMA3COPY((u32)triangle,(u32)0x06016000,64|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
  DMA3COPY((u32)triangle+128,(u32)0x06016400,64|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
  // setup the 'select' triangle as a sprite
  sprite[127].setattr1(OBJ_Y(70)|OBJ_256_COLOR);
  sprite[127].setattr2(OBJ_X(-4)|OBJ_SIZE(1));
  sprite[127].setattr3(OBJ_CHAR(768));
  // set redraw and lowercase
  bool redraw = true, lowercase = false;
  // actual ret string
  string ret = "";
  // locations for the arrow, don't care options
  u8 locationX = 0,locationY = 0, dontcare = 0;
  // keys input
  int keys;
  // until break
  while (true) {
    // if redraw is true, redraw the text
    if (redraw == true) {
	  // wipe text
	  wipeChars();
	  // draw the question
      drawString(question,8,9);
	  // draw current input
	  drawString(ret,90,40);
	  // draw the text
	  if (lowercase) {
        for (int i = 0; i < 13; i++)
          drawChar(i+97,2+(i*15),60,this->lettersprites);
        for (int i = 0; i < 13; i++)
          drawChar(i+110,2+(i*15),100,this->lettersprites);	  
	  }
	  else {
        for (int i = 0; i < 13; i++)
          drawChar(i+65,2+(i*15),60,this->lettersprites);
        for (int i = 0; i < 13; i++)
          drawChar(i+78,2+(i*15),100,this->lettersprites);
	  }
	  // set redraw to false
	  redraw = false;
	}
	
	// scan keys and set them to a variable
	ScanKeys();
	keys = KeysDown();
	// if any arrow keys were pushed
	if (DPAD & keys) {
	  // update the locations
      if (KEY_RIGHT & keys && locationX < 13) {
	    locationX++;
      }
	  if (KEY_LEFT & keys && locationX > 0) {
	    locationX--;
	  }
	  if (KEY_DOWN & keys && locationY < 3)
	    locationY++;
	  if (KEY_UP & keys && locationY > 0) {
	    if (locationX != 13)
		  locationY = 0;
		else
	      locationY--;
	  }
	  // if the location is not the far right options, set arrow under a letter
	  if (locationX != 13) {
  	    sprite[127].setattr2(OBJ_X(-4+(locationX*15))|OBJ_SIZE(1));
		if (locationY)
		  sprite[127].setattr1(OBJ_Y(110)|OBJ_256_COLOR);
		else
		  sprite[127].setattr1(OBJ_Y(70)|OBJ_256_COLOR);
      }
	  // otherwise set the arrow under the far right options
	  else {
	    sprite[127].setattr1(OBJ_Y(57+(locationY*30))|OBJ_256_COLOR);
	    sprite[127].setattr2(OBJ_X(206)|OBJ_SIZE(1));
	  }
	}
	if (KEY_B & keys && !ret.empty()) {
	  ret.erase(ret.size()-1);
	  redraw = true;
	}
	if (KEY_A & keys) {
	  if (locationX == 13 && locationY == 0)
	    break;
	  else if (locationX == 13 && locationY == 1) {
	    lowercase = false;
	  }
	  else if (locationX == 13 && locationY == 2) {
	    lowercase = true;
	  }
	  else if (locationX == 13 && locationY == 3) {
	    switch (dontcare) {
		  case 0: ret = "DontCare"; break;
		  case 1: ret = "RyanA"; break;
		  case 2: ret = "YourMom"; break;
		  case 3: ret = "Duder"; break;
		  case 4: ret = "BrianSea"; break;
		}
		if (dontcare == 4)
		  dontcare = 0;
		else
		  dontcare++;
	  }
	  else if (ret.size() < 8) {
	    if (locationY > 0 && lowercase) {
		  ret += 110 + locationX;
		}
		else if (locationY == 0 && lowercase) {
		  ret += 97 + locationX;
		}
		else if (locationY > 0 && !lowercase) {
		  ret += 78 + locationX;
		}
		else if (locationY == 0 && !lowercase) {
		  ret += 65 + locationX;
		}
	  }
	  redraw = true;
	}
	
	VBlankIntrWait();
  }
  wipeChars();
  return ret;
}

void GFX::drawChar(char letter, u8 X, u8 Y, u8 spriteID) {
  ZOMFGPANIC();
  if (letter == 'e' || letter == 'j')
    sprite[spriteID].setattr1(OBJ_Y(Y+1)|OBJ_256_COLOR);
  else if (letter == 'g' || letter == 'p' || letter == 'q' || letter == 'y')
    sprite[spriteID].setattr1(OBJ_Y(Y+2)|OBJ_256_COLOR);
  else 
    sprite[spriteID].setattr1(OBJ_Y(Y)|OBJ_256_COLOR);
  sprite[spriteID].setattr2(OBJ_X(X)|OBJ_SIZE(0));
  sprite[spriteID].setattr3(OBJ_CHAR(512+((letter-32)*2)));
  this->lettersprites++;
}

void GFX::drawString(const string &word, u8 X, u8 Y) {
  u8 temp = X;
  for (u8 i = 0; i < word.size(); i++) {
    drawChar(word[i],temp,Y,this->lettersprites);
	if (word[i] == '!' || word[i] == '1' || word[i] == 'I' || word[i] == 'i' || word[i] == 'l')
	  temp += 3;
	else if (word[i] == 'j')
	  temp += 4;
	else if (word[i] == 'M' || word[i] == 'W' || word[i] == 'm' || word[i] == 'w')
	  temp += 9;
	else 
	  temp += 6; //question[i]-32];
  }
}

void GFX::wipeChars() {
  for (int i = 0; i < this->lettersprites; i++) {
    sprite[i].setattr1(OBJ_DISABLE);
  }
  this->lettersprites = 0;
}

void GFX::ZOMFGPANIC() {
  if (this->lettersprites >= 127) {
    wipeChars();
	drawString("Out of Sprite Memory!",0,0);
    for (int i = 0; i < 240*160*2; i++)
      video[i] = 6;
    while (1)
      VBlankIntrWait();
  }
}

PasswordTemp GFX::password(const string &name) {
  PasswordTemp ret;
  DMA3COPY((u32)allwhite,(u32)video,19200|DMA_DST_INC|DMA_SRC_FIXED|DMA16|DMA_IMMEDIATE);
  DMA3COPY((u32)arrows,(u32)0x06016000,8192|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
  //DMA3COPY((u32)triangle+128,(u32)0x06016400,64|DMA_DST_INC|DMA_SRC_INC|DMA16|DMA_IMMEDIATE);
  this->setSTDText();
  drawString("Please enter the password for "+name+".",0,0);
  u8 keys,spritenum=0;
  //sprite[127].setattr1(OBJ_Y(70)|OBJ_256_COLOR);
  //sprite[127].setattr2(OBJ_X(0)|OBJ_SIZE(2));
  //sprite[127].setattr3(OBJ_CHAR(768));
  while (spritenum < 5) {
    ScanKeys();
	keys = KeysDown();
	if (keys & KEY_DOWN) {
      sprite[127-spritenum].setattr1(OBJ_Y(70)|OBJ_256_COLOR);
      sprite[127-spritenum].setattr2(OBJ_X(32*spritenum)|OBJ_SIZE(2));
      sprite[127-spritenum].setattr3(OBJ_CHAR(768));
	  ret.pass[spritenum] = KEY_DOWN;
	  spritenum++;
	}
	else if (keys & KEY_LEFT) {
      sprite[127-spritenum].setattr1(OBJ_Y(70)|OBJ_256_COLOR);
      sprite[127-spritenum].setattr2(OBJ_X(32*spritenum)|OBJ_SIZE(2));
      sprite[127-spritenum].setattr3(OBJ_CHAR(776));
	  ret.pass[spritenum] = KEY_LEFT;
	  spritenum++;
	}
	else if (keys & KEY_UP) {
      sprite[127-spritenum].setattr1(OBJ_Y(70)|OBJ_256_COLOR);
      sprite[127-spritenum].setattr2(OBJ_X(32*spritenum)|OBJ_SIZE(2));
      sprite[127-spritenum].setattr3(OBJ_CHAR(784));
	  ret.pass[spritenum] = KEY_UP;
  	  spritenum++;
	}
	else if (keys & KEY_RIGHT) {
      sprite[127-spritenum].setattr1(OBJ_Y(70)|OBJ_256_COLOR);
      sprite[127-spritenum].setattr2(OBJ_X(32*spritenum)|OBJ_SIZE(2));
      sprite[127-spritenum].setattr3(OBJ_CHAR(792));
	  ret.pass[spritenum] = KEY_RIGHT;
  	  spritenum++;
	}
    VBlankIntrWait();
  }
  for (int i = 0; i < 5; i++) {
    sprite[127-i].setattr1(0);
    sprite[127-i].setattr2(0);
    sprite[127-i].setattr3(0);
  }
  //if (ret.pass[0] == KEY_DOWN)
  //  drawString("down",25,25);
  //while (1) {VBlankIntrWait();}
  wipeChars();
  return ret;
}


