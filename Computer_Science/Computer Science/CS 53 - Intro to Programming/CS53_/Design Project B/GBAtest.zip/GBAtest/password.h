/*
 * Author: Ryan Alyea
 * Date: 4/18/06
 * Filename: password.h
 * Instructor: Brian Sea
 * Description: Password class for GBA Texas Hold'em
 */
 
#ifndef password_h
#define password_h

#include "GFX.h"
#include <string>
using namespace std;

class Password {
  int pass1;
  int pass2;
  int pass3;
  int pass4;
  int pass5;

 public:

  //function: setPassword
  //description: sets the password
  //arguments: screen - the GFX instance to push stuff to the screen
  //precondition: none
  //postcondition: password for this is set
  //returns: void
  void setPassword(const string &name, GFX &screen);
  
  //function: askPassword
  //description: asks for the password and will not release the
  //  user until the password is put in.
  //arguments:
  //  name - the user's name to personalize it
  //  screen - the GFX instance to push stuff to the screen
  //precondition: none
  //postcondition: none (VRAM changed + memory residue)
  //returns: void
  void askPassword(const string &name, GFX &screen);
};

#endif
