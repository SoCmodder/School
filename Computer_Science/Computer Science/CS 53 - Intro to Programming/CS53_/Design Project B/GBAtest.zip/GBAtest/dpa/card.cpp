/*
 * Author: Ryan Alyea
 * Date: 3/1/06
 * Filename: card.cpp
 * Instructor: Brian Sea
 * Description: Main function for DPA
 */

#include <iostream>     // input/output fun!
#include <string>       // string excitement for error catching
#include "card.h"

using namespace std;

void initDeck2(Card d[], const unsigned int size) {
  int j = 0;
  int k = 2;
  for (unsigned int i = 0; i < size; i++) {
    d[i].s = static_cast<SUIT>(j);
    d[i].num = k;
    k++;
    if (k > 14) {
      k = 2;
      j++;
    }
  }
}

void shuffleDeck( Deck &d, const unsigned int size )
{
  unsigned int rnd;
  for( unsigned int i = 0; i < size; i++ )
  {
    rnd = rand() % size;
    swap( d.c[i], d.c[rnd] );
  }
  d.pos = 0;
  return;
}

void swap( Card &a, Card &b )
{
  Card temp;
  temp.s = a.s;
  temp.num = a.num;
  a.s = b.s;
  a.num = b.num;
  b.s = temp.s;
  b.num = temp.num;
}

Card giveCard(Deck &d,const unsigned int size) {
  if (d.pos > size)
    shuffleDeck(d,size);
  Card ret = d.c[d.pos];
  d.pos++;
  return ret;
}
