/*
 Author: Adedayo Agbaje
 Date: 3/7/06
 Filename: Design Project A
 Instructor:Brian sea
 Description: The purpose of this program is to create a Texas'Hold'em game.  
 */

 #include <iostream> // input/ output
 #include <string>
 #include "card.h"
 #include "texasrules.h"
 using namespace std;
 
// void initDeck(card d[], const unsigned int size);
// void greetings();
// void goodbye();
 
/* int main()
 {
    initDeck(card d[], const unsigned int size);
    greetings();
    goodbye ();
    return 0;
 }*/
 // Displays greetings
void greeting(string &name)
 { 
    char choice;
    bool rules;
    cout << " What is your name?\n";  
    cin  >> name;
    cout << "Welcome " << name << "! This is the Ultimate Texas Hold'em\n";
    cout << name << "Do know the rules of Texas Holed'em?\n";
    cout << "Enter Y or y for yes and N or n for no\n";  
    cin >> choice;
    if(choice == 'Y' || choice == 'y')
    {
       rules = false;
    }
    else if(choice == 'N' || choice == 'n')
    {
       rules = true;
       cout << "The rules of Texas Hold'em is as followed: \n\n";
       cout << "1. Floor people are to consider to be in the best interest"  
            << "of the game and fairness as the top priority in the"  
            << "decision-making process unusual circumstances can," 
            << "on occasion, dictate that the technical interpretation"
            << "of the rules The floor persons decision is final\n";
       cout << "2. Chip race rule: When it is time to color-up chips," 
            << "they will be raced off with a maximum of one chip going to"
            << "any player.The chip race will always start in the No.1\n"; 
       cout << "3. Odd chips: The odd chip(s) will go to the high hand."
            << "In flop games,when there are two or more high hands or"
            << "two ormore low hands, the odd chips will go to the left"
            << "of the button.\n"; 
       cout << "4. Side pots: Each side pot will be split as a separate pot."
            << "They will not be mixed together before they are split.\n"; 
       cout << "5. Calling for the clock procedures: Once a reasonable" 
            << "amount of time has passed and a clock is called for, a" 
            << "player will be given one minute to make a decision." 
            << "If action has not been taken by the time the minute" 
            << "is over, there will be a 10-second countdown." 
            << "If a player has not acted on his hand by the time the" 
            << "countdown is over, the hand will be dead.\n";
       cout << "6. Dead Button: Tournament play will use a dead button.\n";
       cout << "7. Penalties: A penalty MAY be invoked if a player" 
            << "exposes any card with action pending, if a card(s)" 
            << "goes off the table, if soft-play occurs, or similar"
            << "incidents take place. Penalties WILL be invoked in" 
            << "cases of abuse, disruptive behavior or similar incidents.\n";
       cout << "8. A player must be in their seat by the time all players"
            << "have complete hands in order to have a live hand. Players"
            << "must be at the table to call time. In stud-type games," 
            << "the forced low hand will be immediately dead if the player"
            << "is not there to act on his hand at the time he is required"
            << "to put money in the pot (the minimum bring-in will be posted"
            << "and the hand will be killed).\n";
       cout << "9. All cards will be turned face up once a player is all" 
            << "in and all action is complete.\n";
       cout << "10. If a player puts in a raise of 50 percent or more of"
            << "the previous bet, he will be required to make a full raise." 
            << "The raise will be exactly the minimum raise allowed.\n";
       cout << "11. In limit games, an oversized chip will be constituted"
            << "to be a call  a player does not announce the raise." 
            << "In no-limit, an oversized chip before the flop is a call;"
            << "after the flop, an oversized chip by the initial better" 
            << "put in the pot will constitute the size of the bet." 
            << "In pot-limit and no-limit, if a player states raise"
            << "and throws in an oversized chip,\n"; 
       cout << "12. The one-player-to-a-hand rule will be enforced.\n";
       cout << "13. Tournament and satellite seats will be randomly" 
            << "assigned.\n";
       cout << "14. The English-only rule will be enforced in the"
            << "United States during the play of hands.\n";
       cout << "15. A player who wants to use a cellular phone" 
            << "must step away from the table.\n";
       cout << "16. There will be no foreign chips on the table" 
            << "except for a maximum of one card cap.\n";
       cout << "17. Deck changes will be on the dealer push or"
            << "limit changes or as prescribed by the house.\n"; 
       cout << "18. When time has elapsed in a round and a new"
            << "round is announced, the new limits apply to the next hand.\n"; 
       cout << "19. A player may not miss a hand.\n"; 
       cout << "20. Players must keep their highest denomination"
            << "chips visible at all times.\n";
       cout << "21. No rabbit hunting is allowed.\n";
      
    } 
 }
 void goodbye()
 { 
    cout << "Thanks for playing the Ultimate Texas Hold'em!\n";
    return;
 }  
 /*void initDeck(Card d[], const unsigned int size)
 {
 }*/

  
