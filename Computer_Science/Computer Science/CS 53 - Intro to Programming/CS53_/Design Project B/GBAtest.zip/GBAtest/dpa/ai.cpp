/*
 * Author: Ryan Alyea
 * Date: 3/1/06
 * Filename: main.cpp
 * Instructor: Brian Sea
 * Description: Main function for DPA
 */

#include <ctime>
#include "ai.h"
#include "texasrules.h"
using namespace std;

void createAI(Player &ai) {
  ai.money = STARTING_MONEY;
  ai.isDead = false;
  ai.isHuman = false;
  ai.bet = 0; 
}
 
void sleep2(unsigned int seconds) {
    time_t goal = seconds + time(NULL);
    while (goal > time(NULL));
}

turnAction runHumanTurn (Player &Human, unsigned int &pot,
                         cardTable &theTable) {
  int temp2;
  turnAction temp;
  do {
    cout << "You put out: " << Human.bet << " on the table so far.\n"
         << "A minimum of " << theTable.minBet << " is required to stay in.\n"
         << "You have " << Human.money << " in chips.\n"
         << "There is currently " << pot << " in the pot.\n"
         << "Your best combo is " << cardCombo(Human.card1,Human.card2,
              theTable.flop1,theTable.flop2,theTable.flop3,
              theTable.turn,theTable.river) << "\n"
         << "0)BETINCREASE 1)BETCHECK 2)CHECK 3)FOLD 4)QUIT: ";
    cin >> temp2;
    cin.ignore();
  } while (temp2 > 4 || temp2 < 0 || 
             (temp2 == 2 && Human.bet != theTable.minBet));
  temp = static_cast<turnAction>(temp2);
  if (temp == BETINCREASE) {
    if (Human.money >= theTable.minBet + BET_AMOUNT - Human.bet) {
      Human.money -= theTable.minBet + BET_AMOUNT - Human.bet;
      pot += theTable.minBet + BET_AMOUNT - Human.bet;
      Human.bet += theTable.minBet + BET_AMOUNT - Human.bet;
      theTable.minBet += BET_AMOUNT;
    }
    else {
      temp = BETCHECK;
      cout << "Human COULDN'T BETINCREASE!\n";
    }
  }
  if (temp == BETCHECK) {
    // debug: cout << "BETCHECK CALLED: " << Human.money << " 2: "
    //             << theTable.minBet << " 3: " << Human.bet << "\n";
    if (Human.money >= theTable.minBet - Human.bet) {
      Human.money -= theTable.minBet - Human.bet;
      pot += theTable.minBet - Human.bet;
      Human.bet += theTable.minBet - Human.bet;
    }
    else {
      temp = CHECK;
      cout << "Human COULDN'T BETCHECK!";
    }
  }
  if (temp == CHECK) {
   // at this point, if you cashed a check you can't cash... KILL!
   if (Human.bet != theTable.minBet) {
     temp = KILL;
     cout << "Human KILLED!\n";
   }
  }
  if (temp == FOLD) {
    Human.isFolded = true;
  }
  if (temp == KILL) {
    Human.money = 0;
  }
  return temp;
}
