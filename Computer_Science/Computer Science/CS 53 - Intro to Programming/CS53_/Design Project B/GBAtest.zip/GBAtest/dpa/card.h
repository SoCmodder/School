/*
 * Author: Ryan Alyea
 * Date: 3/1/06
 * Filename: main.cpp
 * Instructor: Brian Sea
 * Description: Main function for DPA
 */

#ifndef card_h
#define card_h

#include <iostream>     // input/output fun!
#include <string>       // string excitement for error catching

enum FACE{ ace = 14, jack = 11, queen = 12, king = 13};

const unsigned int DECKSIZE = 52;

enum SUIT{HEART,DIAMOND,SPADES,CLUBS};

struct Card {
   SUIT s;
   unsigned int num;
};

// function: initDeck
// Purpose:
// This function intializes the array passed in to represent a deck as
// if it was taken out of the box
// Arguments:
// d - the items to fill in
// size - the size of d
// Returns: Nothing
// Precondition: size is <= the actual size of d
// Postcondition: d is now filled with the beginning of a sorted
// deck (1-13, clubs-spades)
void initDeck2( Card d[], const unsigned int size );

// function: swap
// Purpose:
// This function is meant to change the data in a and b
// Arguments:
// a - the first Card to change
// b - the second Card to change
// Returns: Nothing
// Postcondition: a and b are now swapped
void swap( Card &a, Card &b );

struct Deck
{
Card c[DECKSIZE];
unsigned int pos;
};

//Function: shuffleDeck
//Purpose: This function randomizes the deck to simulate a new
//Arguments:
// d - the deck to shuffle
// size - the size of the deck
//Returns: Nothing
//Preconditions:
// 1. The random generator should be seeded
// 2. size is <= to the array of Card objects in d
//Postcondtion: d has been randomized and pos is reset to 0
void shuffleDeck( Deck &d, const unsigned int size );

// Function: giveCard
// Purpose: returns a card from the deck
// Arguments
//   d - deck to take from
//   size - size of deck
// Returns: Card taken
// precondition: size is actual size of deck
// postcondition: pos in deck++

Card giveCard(Deck &d,const unsigned int size);

#endif
