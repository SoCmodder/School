/*
 * Author: Ryan Alyea
 * Date: 3/9/06
 * Filename: gfx.cpp
 * Instructor: Brian Sea
 * Description: Main function for DPA
 */

#include <iostream>
#include <string>
#include "gfx.h"
#include "card.h"
using namespace std;

void clearScreen() {
  for (int i = 0; i < 24; i++)
    cout << "\n";
}

void displayTable (Player Human, Player ai[],
                   const subRound theSubRound, const cardTable &theTable,
                   const unsigned int pot) {
  string cardString = "";
  //line1
  cout << "AI 1 ";
  if (ai[1].isFolded) cout << "FOLD";
  else cout << "    ";
  cout << "         AI 2 ";
  if (ai[2].isFolded) cout << "FOLD";
  else cout << "    ";
  cout << "           AI 3";
  if (ai[3].isFolded) cout << " FOLD";
  cout << "\n";
  //line2
  cout << ai[1].money;
  if (ai[1].money >= 1000)     cout << "              ";
  else if (ai[1].money >= 100) cout << "               ";
  else if (ai[1].money >= 10)  cout << "                ";
  else                         cout << "                 ";
  cout << ai[2].money;
  if (ai[2].money >= 1000)     cout << "                ";
  else if (ai[2].money >= 100) cout << "                 ";
  else if (ai[2].money > 10)   cout << "                  ";
  else                         cout << "                   ";
  cout << ai[3].money << "\n";
  //line 3
  cout << "    /------------------------------\\\n";
  //line 4
  if (ai[0].isFolded) cout << "FOLD";
  else cout << "    ";
  cout << "|                              |";
  if (ai[4].isFolded) cout << "  FOLD";
  cout << "\n";
  //line 5
  cout << "AI 0|          pot: " << pot;
  if (pot >= 1000)     cout << "           |  AI 4";
  else if (pot >= 100) cout << "            |  AI 4";
  else if (pot >= 10)  cout << "             |  AI 4";
  else                 cout << "              |  AI 4";
  cout << "\n";
  //line 6
  cout << ai[0].money;
  if (ai[0].money >= 1000)     cout << "";
  else if (ai[0].money >= 100) cout << " ";
  else if (ai[0].money >= 10)  cout << "  ";
  else                         cout << "   ";
  cout << "|                              |  " << ai[4].money << "\n";
  //line 7
  if (theSubRound == PREFLOP)
    cardString = "?? ?? ?? ?? ??";
  else if (theSubRound == FLOP)
    cardString = smallCard(theTable.flop1) + " " + smallCard(theTable.flop2)+
                 " " + smallCard(theTable.flop3) + " ?? ??";
  else if (theSubRound == TURN)
    cardString = smallCard(theTable.flop1) + " " + smallCard(theTable.flop2)+
                 " " + smallCard(theTable.flop3) + " " +
                 smallCard(theTable.turn) + " ??";
  else
    cardString = smallCard(theTable.flop1) + " " + smallCard(theTable.flop2)+
                 " " + smallCard(theTable.flop3) + " " +
                 smallCard(theTable.turn) + " " + smallCard(theTable.river);
  cout << "    |        "<< cardString << "        |\n";
  //line 8
  cout << "    |                              |\n";
  //line 9
  cout << "    \\------------------------------/\n";
  //line 10
  cout << "\n";
  //line 11
  cout << "Human: " << Human.money << "\n\n";
  
}

void displayCards (const subRound theSubRound, cardTable &theTable) {
  string card1,card2,card3,card4,card5;
  if (theSubRound == FLOP) {
    theTable.flop1 = giveCard(theTable.deck,DECKSIZE);
    theTable.flop2 = giveCard(theTable.deck,DECKSIZE);
    theTable.flop3 = giveCard(theTable.deck,DECKSIZE);
    card1 = smallCard(theTable.flop1);
    card2 = smallCard(theTable.flop2);
    card3 = smallCard(theTable.flop3);
    card4 = "??";
    card5 = "??";
  }
  else if (theSubRound == TURN) {
    theTable.turn = giveCard(theTable.deck,DECKSIZE);
    card1 = smallCard(theTable.flop1);
    card2 = smallCard(theTable.flop2);
    card3 = smallCard(theTable.flop3);
    card4 = smallCard(theTable.turn);
    card5 = "??";
  }
  else {
    theTable.river = giveCard(theTable.deck,DECKSIZE);
    card1 = smallCard(theTable.flop1);
    card2 = smallCard(theTable.flop2);
    card3 = smallCard(theTable.flop3);
    card4 = smallCard(theTable.turn);
    card5 = smallCard(theTable.river);
  }
  //line1
  cout << "/----\\ /----\\ /----\\ /----\\ /----\\\n";
  //line2
  cout << "|" << card1 << "  | |" << card2 << "  | |" << card3 << "  | |";
  if (card4 == "??") cout << "????";
  else cout << card4 << "  ";
  cout << "| |";
  if (card5 == "??") cout << "????";
  else cout << card5 << "  ";
  cout << "|\n";
  //line3
  cout << "|    | |    | |    | |";
  if (card4 == "??") cout << "????";
  else cout << "    ";
  cout << "| |";
  if (card5 == "??") cout << "????";
  else cout << "    ";
  cout << "|\n";
  //line4
  cout << "|  " << card1 << "| |  " << card2 << "| |  " << card3 << "| |";
  if (card4 == "??") cout << "????";
  else cout << "  " << card4;
  cout << "| |";
  if (card5 == "??") cout << "????";
  else cout << "  " << card5;
  cout << "|\n";
  // line5
  cout << "\\----/ \\----/ \\----/ \\----/ \\----/\n";
}

string smallCard (const Card &theCard) {
  string ret = "";
  switch (theCard.num) {
    case 2:
      ret += '2';
      break;
    case 3:
      ret += '3';
      break;
    case 4:
      ret += '4';
      break;
    case 5:
      ret += '5';
      break;
    case 6:
      ret += '6';
      break;
    case 7:
      ret += '7';
      break;
    case 8:
      ret += '8';
      break;
    case 9:
      ret += '9';
      break;
    case 10:
      ret += '0';
      break;
    case 11:
      ret += 'J';
      break;
    case 12:
      ret += 'Q';
      break;
    case 13:
      ret += 'K';
      break;
    case 14:
      ret += 'A';
      break;
    default:
      ret += "BROKEN 131!";
      break;
  }
  switch (theCard.s) {
    case HEART:
      ret += 'H';
      break;
    case DIAMOND:
      ret += 'D';
      break;
    case SPADES:
      ret += 'S';
      break;
    case CLUBS:
      ret += 'C';
      break;
  }
  return ret;
}

void displayHumanCards(const Card &card1, const Card &card2){
  cout << "/----\\ /----\\\n"
       << "|" << smallCard(card1) << "  | |" << smallCard(card2) << "  |\n"
       << "|    | |    |\n"
       << "|  " << smallCard(card1) << "| |  " << smallCard(card2) << "|\n"
       << "\\----/ \\----/\n";
}

