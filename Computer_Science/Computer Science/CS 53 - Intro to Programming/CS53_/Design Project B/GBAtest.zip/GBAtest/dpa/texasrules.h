/*
 * Author: Ryan Alyea
 * Date: 3/1/06
 * Filename: texasrules.h
 * Instructor: Brian Sea
 * Description: Main function for DPA
 */

#ifndef texasrules_h
#define texasrules_h

#include <string>
#include "card.h"
#include "ai.h"
using namespace std;

const unsigned int BET_AMOUNT = 10;

enum comboWin {HIGHCARD,ONEPAIR,TWOPAIR,THREEKIND,STRAIGHT,FLUSH,
               FULLHOUSE, FOURKIND,STRAIGHTFLUSH,ROYALFLUSH};

enum turnAction {BETINCREASE,BETCHECK,CHECK,FOLD,KILL};

enum subRound {PREFLOP,FLOP,TURN,RIVER,WINNER};

struct cardTable {
  Card flop1;
  Card flop2;
  Card flop3;
  Card turn;
  Card river;
  unsigned int minBet;
  unsigned int dealerChip;
  Deck deck;
};

// function: cardCombo
// Purpose:
//   This function takes a 7 card combo, and returns the highest combo
//   from it.
// Arguments
//   card1
//   card2
//   card3
//   card4
//   card5
//   card6
//   card7 - The card to be evalutated
// Precondition: None.
// Postcondition: None.
// Returns: the comboWin.
comboWin cardCombo(const Card &card1, const Card &card2, const Card &card3,
                   const Card &card4, const Card &card5, const Card &card6,
                   const Card &card7);

// function: runHumanTurn
// Purpose:
//  This function is to take care of the human turn, including all couts
//  cins and other functions
// Arguments: 
//   money - human's money
//   pot - how much is in the current pot.
// Precondition: none
// Postcondition: if human bets, take it out of money
// Returns the action the Human will take.
turnAction runHumanTurn(Player &human, unsigned int &pot,
                        cardTable &theTable);

// Function: runAITurn
// Purpose:
//  Function returns the action an AI will take.
// Arugments:
//   ai -- Ai to be run.
//   pot -- money in pot
//   theTable - what's on the table
// preconditions: none.
// postcondidtions: if AI bets, take money from AI to pot.
// Returns: turnAction of AI.

turnAction runAITurn(Player &AI, unsigned int &pot, cardTable &theTable,
                     subRound theRound);

// Function: greeting
// Purpose:
//  Displays a welcome greeting, asks for name, asks if user knows rules,
//  and if not display rules.
// arguments: None
// preconditions: none
// postconditions: none
// Returns: string of username.
void greeting(string &name);

// Function: goodbye
// Purpose:
//  Displays a goodbye sequence.
// Arguments: None
// preconditions: none
// postconditions: none
// Returns: nothing.

void goodbye();

// Function: runSubTurn
// Purpose:
//  Runs a subturn doing everything required, creating the pot for the turn,
//  etc.
// Arguments: 
//  theSubRound - the subround that's being run.
//  theTable - what's on the Table, if anything
//  pot - pot in the current round.
// precondition: none
// postcondidtion: none
// Return: pot - size of current pot.

unsigned int runSubTurn(subRound theSubRound, cardTable &theTable,
                        unsigned int pot, Player &Human, Player ai[]);

// Function: determineWinner
// Purpose:
//   Give pot money to winner
// Arguments:
//   human - human player
//   ai - AI player array
//   pot - what's in the pot
//   theTable - cardTable
// precondition: none
// postcodition: pot cleared, winner has pot added to money
// return: nothing.

void determineWinner(Player &human, Player ai[], unsigned int &pot,
                     cardTable &theTable);

// Function: displayTurnAction
// Purpose: Gives a user-readable form of turnAction
// Arguments:
//   theAction - the action to be displayed
// precondition: none
// postcondition: action is displayed on screen
// returns: you tell me

void displayTurnAction(turnAction theAction);

#endif
