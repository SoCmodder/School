/*
 * Author: Ryan Alyea
 * Date: 3/1/06
 * Filename: main.cpp
 * Instructor: Brian Sea
 * Description: Main function for DPA
 */

#include <iostream>     // input/output fun!
#include <string>       // string excitement for error catching
#include <cstdlib>      // needed for time()
#include "card.h"
#include "texasrules.h"
#include "gfx.h"
#include "ai.h"

using namespace std;

int main() {
  srand(time(NULL));

  string name = "";
  greeting(name);

  subRound theSubRound = PREFLOP;
  unsigned int pot = 0;
  cardTable theTable;
  theTable.minBet = 0;
  theTable.dealerChip = 0;
  initDeck2(theTable.deck.c, DECKSIZE);
  shuffleDeck(theTable.deck,DECKSIZE);
  shuffleDeck(theTable.deck,DECKSIZE);
  shuffleDeck(theTable.deck,DECKSIZE);
  shuffleDeck(theTable.deck,DECKSIZE);
  shuffleDeck(theTable.deck,DECKSIZE);
  theTable.flop1.num = 0;
  theTable.flop2.num = 0;
  theTable.flop3.num = 0;
  theTable.turn.num = 0;
  theTable.river.num = 0;

  Player Human;
  Human.money = STARTING_MONEY;
  Human.isDead = false;
  Human.isHuman = true;
  Human.isFolded = false;
  Human.bet = 0;
  Player ai[NUM_AI_PLAYERS];
  for (unsigned int i = 0; i < NUM_AI_PLAYERS; i++) {
    ai[i].money = STARTING_MONEY;
    ai[i].isDead = false;
    ai[i].isHuman = false;
    ai[i].bet = 0;
    ai[i].isFolded = false;
  }

  while (Human.money > 0) {
    pot = runSubTurn(theSubRound,theTable,pot,Human,ai);
    cout << "DEBUG2";
    if (theSubRound == PREFLOP) theSubRound = FLOP;
    else if (theSubRound == FLOP) theSubRound = TURN;
    else if (theSubRound == TURN) theSubRound = RIVER;
    else {
      determineWinner(Human,ai,pot,theTable);
      theSubRound = PREFLOP;
      shuffleDeck(theTable.deck,DECKSIZE);
      shuffleDeck(theTable.deck,DECKSIZE);
      shuffleDeck(theTable.deck,DECKSIZE);
      shuffleDeck(theTable.deck,DECKSIZE);
      shuffleDeck(theTable.deck,DECKSIZE);
      theTable.flop1.num = 0;
      theTable.flop2.num = 0;
      theTable.flop3.num = 0;
      theTable.turn.num = 0;
      theTable.river.num = 0;
    }
  }
}

unsigned int runSubTurn(subRound theSubRound, cardTable &theTable,
                        unsigned int pot,Player &Human, Player ai[]) {
  unsigned int temp,count=0;
  unsigned int i = 0;
  turnAction lastAction;
  bool goBack = false;
  bool doubleCheck = false;

  if (theSubRound == PREFLOP) {
    if (theTable.dealerChip == 4) {
      ai[4].money -= BET_AMOUNT;
      ai[4].bet += BET_AMOUNT;
      Human.money -= BET_AMOUNT*2;
      Human.bet += BET_AMOUNT*2;
      pot += BET_AMOUNT*3;
    }
    else if (theTable.dealerChip == 5) {
      Human.money -= BET_AMOUNT;
      Human.bet += BET_AMOUNT;
      ai[0].money -= BET_AMOUNT*2;
      ai[0].bet += BET_AMOUNT*2;
      pot += BET_AMOUNT*3;
    }
    else {
      ai[theTable.dealerChip].money -= BET_AMOUNT;
      ai[theTable.dealerChip].bet += BET_AMOUNT;
      ai[theTable.dealerChip + 1].money -= BET_AMOUNT*2;
      ai[theTable.dealerChip + 1].bet += BET_AMOUNT*2;
      pot += BET_AMOUNT*3;
    }
    for (unsigned int i = 0; i < NUM_AI_PLAYERS; i++) {
      ai[i].card1 = giveCard(theTable.deck,DECKSIZE);
      ai[i].card2 = giveCard(theTable.deck,DECKSIZE);
      /*cout << "AI " << i << " CARD1: " << ai[i].card1.num << " S: "
           << ai[i].card1.s << " CARD2: " << ai[i].card2.num << " S: "
           << ai[i].card2.s << "\n";*/
    }
    Human.card1 = giveCard(theTable.deck,DECKSIZE);
    Human.card2 = giveCard(theTable.deck,DECKSIZE);
    theTable.minBet = BET_AMOUNT*2;
  }
  else {
    clearScreen();
    cout << "DEALER FLIPS CARDS!\n";
    displayCards(theSubRound, theTable);
    sleep2(5);
  }
  do {
    for (i = theTable.dealerChip; i < theTable.dealerChip + 6; i++) {
      clearScreen();
      temp = i % 6;
      if (temp == 5 && !Human.isFolded) {
        displayTable(Human,ai,theSubRound,theTable,pot);
        cout << "\n";
        displayHumanCards(Human.card1,Human.card2);
        lastAction = runHumanTurn(Human,pot,theTable);
        cout << "HUMAN DID: ";
        displayTurnAction(lastAction);
        cout << "\n";
        /*if ((temp+1)%6 == theTable.dealerChip) {
          do {
            temp = (temp+1)%6;
            if (temp == 5) {
              cout << "HUMAN IS WINNER!";
              doubleCheck = true;
            }
            else if (ai[temp].isFolded)
              doubleCheck = true;
            else {
              if (ai[temp].bet < theTable.minBet)
                goBack = true;
              else
                goBack = false;
              doubleCheck = false;
            }
          }while(doubleCheck);
        }*/
      }
      else if (!ai[temp].isFolded && temp < 5) {
        lastAction = runAITurn(ai[temp], pot, theTable, theSubRound);
        displayTable(Human,ai,theSubRound,theTable,pot);
        cout << "\n\n\n\n\n\n\n\n\n\n";
        cout << "AI #" << temp << " ";
        displayTurnAction(lastAction);
        cout << " Money: " << ai[temp].money << "\n";
        sleep2(1); 
      }
      if ((temp+1)%6 == theTable.dealerChip) {
        do {
           temp = (temp+1)%6;
           if (temp == 5) {
              if (Human.isFolded)
                doubleCheck = true;
              else {
                if (Human.bet < theTable.minBet)
                  goBack = true;
                else
                goBack = false;
              }
           }
           else if (ai[temp].isFolded)
             doubleCheck = true;
           else {
             if (ai[temp].bet < theTable.minBet)
               goBack = true;
             else
               goBack = false;
             doubleCheck = false;
           }
           count++;
           if (count > 12) break;
        }while(doubleCheck);
      }  
    }
  }while(goBack);
  return pot;
}
