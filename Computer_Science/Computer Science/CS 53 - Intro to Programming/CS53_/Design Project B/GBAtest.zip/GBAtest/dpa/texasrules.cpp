/*
 * Author: Ryan Alyea
 * Date: 3/1/06
 * Filename: card.cpp
 * Instructor: Brian Sea
 * Description: Main function for DPA
 */

#include <iostream>     // input/output fun!
#include <string>       // string excitement for error catching
#include <cmath>	// for pow()
#include "card.h"
#include "texasrules.h"
#include "ai.h"
#include "gfx.h"

using namespace std;

turnAction runAITurn(Player &AI, unsigned int &pot, cardTable &theTable,
                     subRound theRound) {
  int temp;
  double temp2;
  turnAction ret = BETCHECK;
  if (theRound == PREFLOP) {
    // temp holds combo of two cards.
    temp = AI.card1.num * AI.card2.num;
    // if double face cards definitely in.
    if (temp > 120) {
      // 33% chance to BETINCREASE, else BETCHECK
      if (rand()%3 == 2) 
        ret = BETINCREASE;
      else
        ret = BETCHECK;
    }
    // else if fairly decent cards, stay in
    else if (temp > 60) {
      // 25% chance of BETINCREASE
      if (rand()%4 == 3)
        ret = BETINCREASE;
      // if can check, then check
      else if (AI.bet == theTable.minBet)
        ret = CHECK;
      else
        ret = BETCHECK;
    }
    // else crappy cards
    else {
      // 20% chance of bluffing
      if (rand()%5 == 4)
        ret = BETINCREASE;
      // if can check, 50% of checking
      else if (rand()%2 == 1 && AI.bet == theTable.minBet)
        ret = CHECK;
      // 33% chance of rasing to minimum bet
      else if (rand()%3 == 2)
        ret = BETCHECK;
      // if rands fail, FOLD!
      else
        ret = FOLD;
    }
  }
  else {
    // temp holds AI's high card, temp2 holds AI card score.
    if (AI.card1.num > AI.card2.num)
      temp = AI.card1.num;
    else
      temp = AI.card2.num;
    temp2 = pow(10.0,static_cast<double>(cardCombo(AI.card1,AI.card2,
                   theTable.flop1,theTable.flop2,theTable.flop3,
                   theTable.turn,theTable.river)))
             * temp;
    // if crappy combos
    if (temp2 < 1000) {
      // 20% chance of bluffing
      if (rand()%5 == 4)
        ret = BETINCREASE;
      // if can check, 50% of checking
      else if (rand()%2 == 1 && AI.bet == theTable.minBet)
        ret = CHECK;
      // 33% chance of rasing to minimum bet
      else if (rand()%3 == 2)
        ret = BETCHECK;
      // if rands fail, FOLD!
      else
        ret = FOLD;
    }
    else if (temp2 < 1000000) {
      // 25% chance of BETINCREASE
      if (rand()%4 == 2)
        ret = BETINCREASE;
      // if can check, then check
      else if (AI.bet == theTable.minBet)
        ret = CHECK;
      else
        ret = BETCHECK;

    }
    else
    {
      // this is a darn good combo, increase it 33% chance!
      if (rand()%3 == 1)
        ret = BETINCREASE;
      else
        ret = BETCHECK;
    }
  }
  if (ret == BETINCREASE) {
    if (AI.money >= theTable.minBet + BET_AMOUNT - AI.bet) {
      AI.money -= theTable.minBet + BET_AMOUNT - AI.bet;
      pot += theTable.minBet + BET_AMOUNT - AI.bet;
      AI.bet += theTable.minBet + BET_AMOUNT - AI.bet;
      theTable.minBet += BET_AMOUNT;
    }
    else {
      ret = BETCHECK;
      cout << "AI COULDN'T BETINCREASE!\n";
    }
  }
  if (ret == BETCHECK) {
    // debug: cout << "BETCHECK CALLED: " << AI.money << " 2: "
    //             << theTable.minBet << " 3: " << AI.bet << "\n";
    if (AI.money >= theTable.minBet - AI.bet) {
      AI.money -= theTable.minBet - AI.bet;
      pot += theTable.minBet - AI.bet;
      AI.bet += theTable.minBet - AI.bet;
    }
    else {
      ret = CHECK;
      cout << "AI COULDN'T BETCHECK!";
    }
  }
  if (ret == CHECK) {
   // at this point, if you cashed a check you can't cash... KILL!
   if (AI.bet != theTable.minBet) {
     ret = KILL;
     cout << "AI KILLED!\n";
   }
  }
  if (ret == FOLD) {
    AI.isFolded = true;
  }
  return ret;
}

comboWin cardCombo(const Card &card1, const Card &card2, const Card &card3,
                   const Card &card4, const Card &card5, const Card &card6,
                   const Card &card7) {
  comboWin ret = HIGHCARD;

  // initalize general list of what's avalable.

  Card card[7];
  card[0] = card1;
  card[1] = card2;
  card[2] = card3;
  card[3] = card4;
  card[4] = card5;
  card[5] = card6;
  card[6] = card7;

  bool CA=0,DA=0,SA=0,HA=0;
  bool CK=0,DK=0,SK=0,HK=0;
  bool CQ=0,DQ=0,SQ=0,HQ=0;
  bool CJ=0,DJ=0,SJ=0,HJ=0;
  bool C10=0,D10=0,S10=0,H10=0;
  bool C9=0,D9=0,S9=0,H9=0;
  bool C8=0,D8=0,S8=0,H8=0;
  bool C7=0,D7=0,S7=0,H7=0;
  bool C6=0,D6=0,S6=0,H6=0;
  bool C5=0,D5=0,S5=0,H5=0;
  bool C4=0,D4=0,S4=0,H4=0;
  bool C3=0,D3=0,S3=0,H3=0;
  bool C2=0,D2=0,S2=0,H2=0;

  int numSpades=0,numHearts=0,numClubs=0,numDiamonds=0;
  int num[13];
  for (int i = 0; i < 13; i++)
    num[i] = 0;

  // GAH LONG THING! BUT IT GIVES GENERAL COUNT FOR EASY FINDING.

  for (int i = 0; i < 7; i++) {
    if (card[i].s == SPADES) {
      numSpades++;
      switch (card[i].num) {
        case 2: S2 = true;   num[0]++; break;
        case 3: S3 = true;   num[1]++; break;
        case 4: S4 = true;   num[2]++; break;
        case 5: S5 = true;   num[3]++; break;
        case 6: S6 = true;   num[4]++; break;
        case 7: S7 = true;   num[5]++; break;
        case 8: S8 = true;   num[6]++; break;
        case 9: S9 = true;   num[7]++; break;
        case 10: S10 = true; num[8]++; break;
        case 11: SJ = true;  num[9]++; break;
        case 12: SQ = true;  num[10]++; break;
        case 13: SK = true;  num[11]++; break;
        case 14: SA = true;  num[12]++; break;
      }
    }
    else if (card[i].s == CLUBS) {
      numClubs++;
      switch (card[i].num) {
        case 2: C2 = true;   num[0]++; break;
        case 3: C3 = true;   num[1]++; break;
        case 4: C4 = true;   num[2]++; break;
        case 5: C5 = true;   num[3]++; break;
        case 6: C6 = true;   num[4]++; break;
        case 7: C7 = true;   num[5]++; break;
        case 8: C8 = true;   num[6]++; break;
        case 9: C9 = true;   num[7]++; break;
        case 10: C10 = true; num[8]++; break;
        case 11: CJ = true;  num[9]++; break;
        case 12: CQ = true;  num[10]++; break;
        case 13: CK = true;  num[11]++; break;
        case 14: CA = true;  num[12]++; break;
      }
    }
    else if (card[i].s == DIAMOND) {
      numDiamonds++;
      switch (card[i].num) {
        case 2: D2 = true;   num[0]++; break;
        case 3: D3 = true;   num[1]++; break;
        case 4: D4 = true;   num[2]++; break;
        case 5: D5 = true;   num[3]++; break;
        case 6: D6 = true;   num[4]++; break;
        case 7: D7 = true;   num[5]++; break;
        case 8: D8 = true;   num[6]++; break;
        case 9: D9 = true;   num[7]++; break;
        case 10: D10 = true; num[8]++; break;
        case 11: DJ = true;  num[9]++; break;
        case 12: DQ = true;  num[10]++; break;
        case 13: DK = true;  num[11]++; break;
        case 14: DA = true;  num[12]++; break;
      }
    }
    else if (card[i].s == HEART) {
      numHearts++;
      switch (card[i].num) {
        case 2: H2 = true;   num[0]++; break;
        case 3: H3 = true;   num[1]++; break;
        case 4: H4 = true;   num[2]++; break;
        case 5: H5 = true;   num[3]++; break;
        case 6: H6 = true;   num[4]++; break;
        case 7: H7 = true;   num[5]++; break;
        case 8: H8 = true;   num[6]++; break;
        case 9: H9 = true;   num[7]++; break;
        case 10: H10 = true; num[8]++; break;
        case 11: HJ = true;  num[9]++; break;
        case 12: HQ = true;  num[10]++; break;
        case 13: HK = true;  num[11]++; break;
        case 14: HA = true;  num[12]++; break;
      }
    }
  }
  
  /*for (int i = 0; i < 13; i++) {
    cout << i << ": " << num[i] << "\n";
  }
  cout << CA << DA << SA << HA << "\n";
  cout << CK << DK << SK << HK << "\n";
  cout << CQ << DQ << SQ << HQ << "\n";
  cout << CJ << DJ << SJ << HJ << "\n";
  cout << C10 << D10 << S10 << H10 << "\n";
  cout << C9 << D9 << S9 << H9 << "\n";
  cout << C8 << D8 << S8 << H8 << "\n";
  cout << C7 << D7 << S7 << H7 << "\n";
  cout << C6 << D6 << S6 << H6 << "\n";
  cout << C5 << D5 << S5 << H5 << "\n";
  cout << C4 << D4 << S4 << H4 << "\n";
  cout << C3 << D3 << S3 << H3 << "\n";
  cout << C2 << D2 << S2 << H2 << "\n";*/

  // check for specific combinations
  if (CA&&CK&&CQ&&CJ&&C10) ret = ROYALFLUSH;
  else if(DA&&DK&&DQ&&DJ&&D10) ret = ROYALFLUSH;
  else if(HA&&HK&&HQ&&HJ&&H10) ret = ROYALFLUSH;
  else if(SA&&SK&&SQ&&SJ&&S10) ret = ROYALFLUSH;
  else if(CK&&CQ&&CJ&&C10&&C9) ret = STRAIGHTFLUSH;
  else if(C8&&CQ&&CJ&&C10&&C9) ret = STRAIGHTFLUSH;
  else if(C8&&C7&&CJ&&C10&&C9) ret = STRAIGHTFLUSH;
  else if(C8&&C7&&C6&&C10&&C9) ret = STRAIGHTFLUSH;
  else if(C8&&C7&&C6&&C5&&C9) ret = STRAIGHTFLUSH;
  else if(C8&&C7&&C6&&C5&&C4) ret = STRAIGHTFLUSH;
  else if(C3&&C7&&C6&&C5&&C4) ret = STRAIGHTFLUSH;
  else if(C3&&C2&&C6&&C5&&C4) ret = STRAIGHTFLUSH;
  else if(C3&&C2&&CA&&C5&&C4) ret = STRAIGHTFLUSH;
  else if(DK&&DQ&&DJ&&D10&&D9) ret = STRAIGHTFLUSH;
  else if(D8&&DQ&&DJ&&D10&&D9) ret = STRAIGHTFLUSH;
  else if(D8&&D7&&DJ&&D10&&D9) ret = STRAIGHTFLUSH;
  else if(D8&&D7&&D6&&D10&&D9) ret = STRAIGHTFLUSH;
  else if(D8&&D7&&D6&&D5&&D9) ret = STRAIGHTFLUSH;
  else if(D8&&D7&&D6&&D5&&D4) ret = STRAIGHTFLUSH;
  else if(D3&&D7&&D6&&D5&&D4) ret = STRAIGHTFLUSH;
  else if(D3&&D2&&D6&&D5&&D4) ret = STRAIGHTFLUSH;
  else if(D3&&D2&&DA&&D5&&D4) ret = STRAIGHTFLUSH;
  else if(HK&&HQ&&HJ&&H10&&H9) ret = STRAIGHTFLUSH;
  else if(H8&&HQ&&HJ&&H10&&H9) ret = STRAIGHTFLUSH;
  else if(H8&&H7&&HJ&&H10&&H9) ret = STRAIGHTFLUSH;
  else if(H8&&H7&&H6&&H10&&H9) ret = STRAIGHTFLUSH;
  else if(H8&&H7&&H6&&H5&&H9) ret = STRAIGHTFLUSH;
  else if(H8&&H7&&H6&&H5&&H4) ret = STRAIGHTFLUSH;
  else if(H3&&H7&&H6&&H5&&H4) ret = STRAIGHTFLUSH;
  else if(H3&&H2&&H6&&H5&&H4) ret = STRAIGHTFLUSH;
  else if(H3&&H2&&HA&&H5&H4) ret = STRAIGHTFLUSH;
  else if(SK&&SQ&&SJ&&S10&&S9) ret = STRAIGHTFLUSH;
  else if(S8&&SQ&&SJ&&S10&&S9) ret = STRAIGHTFLUSH;
  else if(S8&&S7&&SJ&&S10&&S9) ret = STRAIGHTFLUSH;
  else if(S8&&S7&&S6&&S10&&S9) ret = STRAIGHTFLUSH;
  else if(S8&&S7&&S6&&S5&&S9) ret = STRAIGHTFLUSH;
  else if(S8&&S7&&S6&&S5&&S4) ret = STRAIGHTFLUSH;
  else if(S3&&S7&&S6&&S5&&S4) ret = STRAIGHTFLUSH;
  else if(S3&&S2&&S6&&S5&&S4) ret = STRAIGHTFLUSH;
  else if(S3&&S2&&SA&&S5&&S4) ret = STRAIGHTFLUSH;
  // otherwise check for easier combinations
  else {
    for (int i = 0; i < 13; i++) {
      // theory: if there's four of each kind, four of a kind!
      if (num[i] == 4) {
        return FOURKIND;
      }
    }
    for (int i = 0; i < 13; i++) {
      for (int j = 0; j < 13; j++) {
        // theory: if 3 of one kind and 2 of another, full house
        if (i != j && num[i] >= 3 && num[j] >= 2) {
          return FULLHOUSE;
        }
      }
    }
    if (numSpades >= 5) {
      return FLUSH;
    }
    if (numHearts >= 5) {
      return FLUSH;
    }
    if (numDiamonds >= 5) {
      return FLUSH;
    }
    if (numClubs >= 5) {
      return FLUSH;
    }
    // theory: should be picked if 5 numbers in a row
    for (int i = 0; i < 13; i++) {
      if (num[i] >= 1 && num[(i+1)%13] >= 1 && num[(i+2)%13] >= 1 &&
          num[(i+3)%13] >= 1 && num[(i+4)%13] >= 1) {
        //cout << "STRAIGHT: " << i << "\n";
        return STRAIGHT;
      }
    }
    // three of a kind!
    for (int i = 0; i < 13; i++) {
      if (num[i] >= 3) {
        //cout << "THREEKIND: " << i << "\n";
        return THREEKIND;
      }
    }
    for (int i = 0; i < 13; i++) {
      for (int j = 0; j < 13; j++) {
        // theory: if 2 of one kind and 2 of another, two pair
        if (i != j && num[i] >= 2 && num[j] >= 2) {
          //cout << "TWOPAIR: " << i << j << "\n";
          return TWOPAIR;
        }
      }
    }
    for (int i = 0; i < 13; i++) {
      if (num[i] >= 2) {
        //cout << "ONEPAIR: " << i << "\n";
        return ONEPAIR;
      }      
    }
  } 
  return ret;
}

void determineWinner(Player &human, Player ai[], unsigned int &pot,
                     cardTable &theTable) {

  unsigned int winner = 0;
  unsigned int highcard1,highcard2;  

  Player players[NUM_AI_PLAYERS+1];
  for (unsigned int i = 0; i < NUM_AI_PLAYERS; i++)
    players[i] = ai[i];
  players [NUM_AI_PLAYERS] = human;

  for (unsigned int i = 0; i < NUM_AI_PLAYERS + 1; i++) {
    if (winner == i && players[i].isFolded) {
      winner++;
    }
    else if (winner != i && !players[i].isFolded) {
      if (cardCombo(players[winner].card1,players[winner].card2,
                   theTable.flop1,
            theTable.flop2,theTable.flop3,theTable.turn,theTable.river) <
          cardCombo(players[i].card1,players[i].card2,theTable.flop1,
            theTable.flop2,theTable.flop3,theTable.turn,theTable.river)) {
        winner = i;
      }
      else if (cardCombo(players[winner].card1,players[winner].card2,
                  theTable.flop1,
            theTable.flop2,theTable.flop3,theTable.turn,theTable.river) ==
          cardCombo(players[i].card1,players[i].card2,theTable.flop1,
            theTable.flop2,theTable.flop3,theTable.turn,theTable.river)) {
        highcard1 = players[winner].card1.num;
        if (players[winner].card2.num > highcard1)
          highcard1 = players[winner].card2.num;
        highcard2 = players[i].card1.num;
        if (players[i].card2.num > highcard2)
          highcard2 = players[i].card2.num;
        // if winners < current highcard
        if (highcard1 < highcard2) {
          winner = i;
        }
        else if (highcard1 == highcard2) {
          cout << "SPLIT POT!!\n\n";
        }
      }
    }
  }
  clearScreen();
  if (winner == NUM_AI_PLAYERS) {
    cout << "HUMAN IS WINNER! YAY!\n";
    human.money += pot;
  }
  else {
    cout << "AI #" << winner << " IS WINNER! " <<
      cardCombo(ai[winner].card1,ai[winner].card2,theTable.flop1,
            theTable.flop2,theTable.flop3,theTable.turn,theTable.river)
      << " " <<
      smallCard(ai[winner].card1) << " " << smallCard(ai[winner].card2)
      << "\n";
    ai[winner].money += pot;
  }
  cout << "Press any key to continue...\n";
  getchar();
  human.isFolded = false;
  human.bet = 0;
  pot = 0;
  theTable.minBet = 0; 
  theTable.dealerChip = (theTable.dealerChip+1)%6;
  for (unsigned int i = 0; i < NUM_AI_PLAYERS; i++) {
    ai[i].isFolded = false;
    ai[i].bet = 0;
  }
}

void displayTurnAction(turnAction theAction) {
  switch (theAction){
    case BETINCREASE:
      cout << "rasied by " << BET_AMOUNT << ".";
      break;
    case BETCHECK:
      cout << "called.";
      break;
    case CHECK:
      cout << "checked.";
      break;
    case FOLD:
      cout << "folded.";
      break;
    case KILL:
      cout << "ran out of money!";
      break;
    default:
      cout << "SOMETHING BROKE! ERROR 345!";
      break;
  }
}
